using Photon.Pun;
using UnityEngine;

public class UIManager : MonoBehaviourPunCallbacks
{
    public GameObject[] canvases;
    public GameObject gameObject4;  // GameObject(4)를 참조

    // 파츠 오브젝트들
    public GameObject leftArm;  // 왼쪽 팔
    public GameObject rightArm; // 오른쪽 팔
    public GameObject leftLeg;  // 왼쪽 다리
    public GameObject rightLeg; // 오른쪽 다리

    public GameObject mousePosLA;  // 왼쪽 팔
    public GameObject mousePosRA; // 오른쪽 팔
    public GameObject mousePosLL;  // 왼쪽 다리
    public GameObject mousePosRL; // 오른쪽 다리

    private GameObject[] allParts; // 4개의 파츠를 배열로 관리
    private GameObject[] allMousePos;
    private PhotonView PV; // PhotonView 변수 추가

    void Start()
    {
        PV = GetComponent<PhotonView>(); // PhotonView 할당
    }

    public void ShowCanvas(int index)
    {
        if (canvases == null || canvases.Length == 0) return;
        if (index < 0 || index >= canvases.Length) return;

        for (int i = 0; i < canvases.Length; i++)
        {
            canvases[i].SetActive(i == index);  // 현재 인덱스만 활성화
        }
    }

    // 플레이 버튼 클릭 시 호출되는 메서드
    public void OnPlayButtonPressed()
    {
        if (PhotonNetwork.IsMasterClient) // 방장 확인
        {
            if (gameObject4 != null)
            {
                PV.RPC("ChangeScreenAndDisableRoomCanvas", RpcTarget.All);

                int playerCount = PhotonNetwork.PlayerList.Length;
                allParts = new GameObject[] { leftArm, rightArm, leftLeg, rightLeg };
                allMousePos = new GameObject[] { mousePosLA, mousePosRA, mousePosLL, mousePosRL };

                GameObject[] activeParts = new GameObject[playerCount];
                GameObject[] activePos = new GameObject[playerCount];

                for (int i = 0; i < playerCount; i++)
                {
                    int r = Random.Range(0, allParts.Length);
                    GameObject selectedPart = allParts[r];
                    GameObject selectedMousePos = allMousePos[r];
                    // 이미 선택된 파츠를 중복할당하지 않도록 방지
                    while (System.Array.Exists(activeParts, part => part == selectedPart))
                    {
                        int a = Random.Range(0, allParts.Length);
                        selectedPart = allParts[a];
                        selectedMousePos = allMousePos[a];
                    }

                    selectedPart.SetActive(true);
                    activeParts[i] = selectedPart;
                    activePos[i] = selectedMousePos;

                    PhotonView photonView = selectedPart.GetComponent<PhotonView>();
                    PhotonView photonView2 = selectedMousePos.GetComponent<PhotonView>();

                    if (photonView != null)
                    {
                        photonView.TransferOwnership(PhotonNetwork.PlayerList[i].ActorNumber); // 소유권 할당
                        photonView2.TransferOwnership(PhotonNetwork.PlayerList[i].ActorNumber);
                        // 소유권이 제대로 이전되었는지 확인
                        if (!photonView.IsMine)  // 소유권 이전 실패시
                        {
                            photonView.RequestOwnership(); // 소유권을 다시 요청
                        }
                    }

                    // 파츠 활성화 전파
                    PV.RPC("ActivatePartRPC", RpcTarget.AllBuffered, selectedPart.name);
                    PV.RPC("ActivatePartRPC", RpcTarget.AllBuffered, selectedMousePos.name);
                }

                Debug.Log("파츠 활성화 및 플레이어 할당 완료!");
            }
            else
            {
                Debug.LogError("GameObject(4)가 할당되지 않았습니다. 인스펙터에서 할당해 주세요.");
            }
        }
        else
        {
            Debug.LogWarning("방장만 이 버튼을 누를 수 있습니다.");
        }
    }

    [PunRPC]
    void ChangeScreenAndDisableRoomCanvas()
    {
        gameObject4.SetActive(true);  // 모든 플레이어의 화면을 변경

        GameObject roomCanvas = GameObject.Find("RoomCanvas(3)");
        if (roomCanvas != null)
        {
            roomCanvas.SetActive(false);
        }
        else
        {
            Debug.LogError("RoomCanvas(3)를 찾을 수 없습니다.");
        }
    }

    // 각 플레이어에게 랜덤으로 파츠 할당
    // 방장이 각 플레이어에게 파츠를 할당할 때
    public void AssignRandomPartToPlayer()
    {
        allParts = new GameObject[] { leftArm, rightArm, leftLeg, rightLeg };
        int playerCount = PhotonNetwork.PlayerList.Length;

        if (playerCount == 1)
        {
            GameObject selectedPart = allParts[Random.Range(0, allParts.Length)];
            selectedPart.SetActive(true);

            PhotonView photonView = selectedPart.GetComponent<PhotonView>();
            if (photonView != null)
            {
                photonView.RequestOwnership(); // 소유권을 요청
            }
        }
        else
        {
            GameObject[] activeParts = new GameObject[playerCount];

            for (int i = 0; i < playerCount; i++)
            {
                GameObject selectedPart = allParts[Random.Range(0, allParts.Length)];

                while (System.Array.Exists(activeParts, part => part == selectedPart))
                {
                    selectedPart = allParts[Random.Range(0, allParts.Length)];
                }

                selectedPart.SetActive(true);
                activeParts[i] = selectedPart;

                PhotonView photonView = selectedPart.GetComponent<PhotonView>();
                if (photonView != null)
                {
                    photonView.TransferOwnership(PhotonNetwork.PlayerList[i].ActorNumber); // 소유권을 이전

                    // 소유권이 제대로 이전되었는지 확인
                    if (!photonView.IsMine)  // 소유권 이전 실패시
                    {
                        photonView.RequestOwnership(); // 소유권을 다시 요청
                    }
                }
            }
        }
    }

    // 파츠 활성화 전파
    [PunRPC]
    void ActivatePartRPC(string partName)
    {
        GameObject part = GameObject.Find(partName);
        if (part != null) part.SetActive(true);
    }
}
