using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MousePos : MonoBehaviour
{
    //public static MousePos Minst;
    public Vector3 mousePos;
    // Start is called before the first frame update
    private void Awake()
    {
        //Minst = this; 
    }
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        mousePos.z = 0;
    }
}
